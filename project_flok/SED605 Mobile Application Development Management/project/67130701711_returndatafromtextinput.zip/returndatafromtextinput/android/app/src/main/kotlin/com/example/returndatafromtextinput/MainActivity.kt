package com.example.returndatafromtextinput

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
